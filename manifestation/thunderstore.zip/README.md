Lure-based mod that adds compatibility between various modded species and modded patterns. 
Doesn't have much right now, was released early because I was just sitting on the unreleased WIP.