0.1.1
- Fixed some filenames, sorry

0.1.0
- Added Clown pattern for Possum and Borzoi